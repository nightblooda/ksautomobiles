-- MySQL dump 10.13  Distrib 5.6.49, for Linux (x86_64)
--
-- Host: localhost    Database: ksautomobileDB
-- ------------------------------------------------------
-- Server version	5.6.49-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ksautomobileDB`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ksautomobileDB` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ksautomobileDB`;

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `billno` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `vehicleno` varchar(255) NOT NULL,
  `vehiclename` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `km` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobileno` varchar(13) NOT NULL,
  `fid` int(11) DEFAULT NULL,
  `total` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `billno` (`billno`),
  KEY `fkeyid` (`fid`),
  CONSTRAINT `fkeyid` FOREIGN KEY (`fid`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bills`
--

LOCK TABLES `bills` WRITE;
/*!40000 ALTER TABLE `bills` DISABLE KEYS */;
INSERT INTO `bills` VALUES (5,'v1','himanshu choudhary','rj 32 ca 7846','audi r8','2019-11-03',786,'himanshux7x7x7@gmail.com','9106889708',2,800.00),(6,'v2','himanshu choudhary','rj 32 ca 7846','audi r8','2019-11-03',48343,'himanshux7x7x7@gmail.com','9106889708',2,550.00),(7,'v3','himanshu choudhary','rj 32 ca 7847','Audi r7','2019-11-03',3473,'','9106889708',2,400.00),(11,'v4','himanshu choudhary','rj 32 ca 7846','audi r8','2019-11-03',32444,'','9106889708',2,2000.00),(12,'v5','himanshu choudhary','rj 32 ca 7846','audi r8','2019-11-03',32444,'','9106889708',2,3000.00),(13,'v6','Ayush','hr 26 cg 3478','audi a5','2019-11-04',4837,'ayush@gmail.com','9116889708',2,2950.00),(14,'v7','Ayush','hr 26 cg 3478','audi a5','2019-11-04',4839,'ayush@gmail.com','9116889708',2,4150.00),(16,'v8','trishant choudhary','hr 26 cg 4353','rolls phantom','2019-11-05',4837,'trishant@gmail.com','9123012307',2,450.00),(17,'v9','Aman','hr 26 ws 3492','rolls royce','2019-11-09',8493,'aman@gmail.com','9837263724',2,6000.00),(18,'1','Mukesh','Rj32ca3990','Swift','2019-11-13',70000,'','9782606026',1,340.00),(19,'002','Mukesh','Rj32ca3990','Swift','2019-11-13',70000,'','9782606026',1,340.00),(20,'010','Mukesh','Rj32ca3990','Swift','2019-11-13',70000,'','9782606026',1,340.00),(21,'0111','Mukesh','Rj32ca3990','Swift','2019-11-13',70000,'','9782606026',1,340.00);
/*!40000 ALTER TABLE `bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `particulars`
--

DROP TABLE IF EXISTS `particulars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `particulars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bills_fid` varchar(255) DEFAULT NULL,
  `particular` varchar(255) NOT NULL,
  `rate` decimal(11,2) NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `gst` decimal(5,2) NOT NULL,
  `quantity` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkeybillno` (`bills_fid`),
  CONSTRAINT `fkeybillno` FOREIGN KEY (`bills_fid`) REFERENCES `bills` (`billno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `particulars`
--

LOCK TABLES `particulars` WRITE;
/*!40000 ALTER TABLE `particulars` DISABLE KEYS */;
INSERT INTO `particulars` VALUES (8,'v1','Labour',100.00,200.00,0.00,2.00),(9,'v1','Wheel Balancing',150.00,600.00,0.00,4.00),(10,'v2','Labour',150.00,150.00,0.00,1.00),(11,'v2','Weight Alloy',100.00,400.00,0.00,4.00),(12,'v3','Labour',150.00,150.00,0.00,1.00),(13,'v3','Dry Cleaners',250.00,250.00,0.00,1.00),(14,'v4','Labour',2000.00,2000.00,0.00,1.00),(15,'v5','Labour',1000.00,1000.00,0.00,1.00),(16,'v5','Wheel Alignment',2000.00,2000.00,0.00,1.00),(17,'v6','Labour',100.00,200.00,0.00,2.00),(18,'v6','Wheel Alignment',200.00,200.00,0.00,1.00),(19,'v6','Wheel Balancing',200.00,800.00,0.00,4.00),(20,'v6','Weight Alloy',50.00,200.00,0.00,4.00),(21,'v6','Weight Ordinary',200.00,200.00,0.00,1.00),(22,'v6','Washing',300.00,300.00,0.00,1.00),(23,'v6','Wall',50.00,50.00,0.00,1.00),(24,'v6','Tyre Changes',100.00,200.00,0.00,2.00),(25,'v6','Side Changes',50.00,100.00,0.00,2.00),(26,'v6','Camber Bolt/Sim',30.00,300.00,0.00,10.00),(27,'v6','Rim Straight',200.00,400.00,0.00,2.00),(28,'v7','Labour',100.00,200.00,0.00,2.00),(29,'v7','Wheel Alignment',200.00,200.00,0.00,1.00),(30,'v7','Wheel Balancing',200.00,800.00,0.00,4.00),(31,'v7','Weight Alloy',50.00,200.00,0.00,4.00),(32,'v7','Weight Ordinary',200.00,200.00,0.00,1.00),(33,'v7','Washing',300.00,300.00,0.00,1.00),(34,'v7','Wall',50.00,50.00,0.00,1.00),(35,'v7','Tyre Changes',100.00,200.00,0.00,2.00),(36,'v7','Side Changes',50.00,100.00,0.00,2.00),(37,'v7','Camber Bolt/Sim',30.00,300.00,0.00,10.00),(38,'v7','Rim Straight',200.00,400.00,0.00,2.00),(39,'v7','Dry Cleaners',200.00,200.00,0.00,1.00),(40,'v7','A.C. Gas',1000.00,1000.00,0.00,1.00),(41,'v8','Wheel Alignment',250.00,250.00,0.00,1.00),(42,'v8','Wheel Balancing',100.00,200.00,0.00,2.00),(43,'v9','Labour',500.00,500.00,0.00,1.00),(44,'v9','Wheel Alignment',2500.00,2500.00,0.00,1.00),(45,'v9','A.C. Gas',2000.00,2000.00,0.00,1.00),(46,'v9','Washing',1000.00,1000.00,0.00,1.00);
/*!40000 ALTER TABLE `particulars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `response`
--

DROP TABLE IF EXISTS `response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` varchar(255) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=125 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `response`
--

LOCK TABLES `response` WRITE;
/*!40000 ALTER TABLE `response` DISABLE KEYS */;
INSERT INTO `response` VALUES (1,'Himanshu','himanshu@gmail.com','The feedback','Here is the message.',1,'2019-11-09 05:05:37'),(2,'Aysuh','arun250819roy@gmail.com','Another feedback','this is the message for another feedback.',1,'2019-11-09 06:32:03'),(3,'Suraj','suraj@gmail.com','Suggestion for new schemes.','Eos ipsa est voluptates. Nostrum nam libero ipsa vero. Debitis quasi sit eaque numquam similique commodi harum aut temporibus.Eos ipsa est voluptates. Nostrum nam libero ipsa vero. Debitis quasi sit eaque numquam similique commodi harum aut temporibus.',1,'2019-11-09 14:33:02'),(4,'Rohit','rohit@gmail.com','Just a test.','This is the test message.',1,'2019-11-10 04:25:33'),(5,'Akash','akash@gmail.com','testing.','this is testing message.',1,'2019-11-13 10:03:59'),(6,'hello','hwsdf@gm.cmc','sdaf','fewfaqwdf',1,'2019-11-26 09:19:38'),(7,'CharlesSmurf','yourmail@gmail.com','Test, just a test','Hello. And Bye.',1,'2019-12-05 22:27:48'),(8,'Dating for sÐµÑ… | Ð¡anada: https://klurl.nl/?u=lHE95N8K','gggirl34@hotmail.com','SeÑ… dÐ°ting sitÐµ, sÐµx on a first dÐ°tÐµ, sÐµx immediatelÑƒ: https://links.wtf/DMZC','DÐ°ting site for seÑ… with girls from ÐustrÐ°liÐ°: https://links.wtf/Gt3X',1,'2019-12-22 11:34:41'),(9,'Adult 1 dÐ°ting Ð°pÑ€: https://klurl.nl/?u=XjUeqvs1','','DÐ°ting sitÐµ fÐ¾r sÐµx with girls in your city: https://onlineuniversalwork.com/adultdating561673','SÐµÑ… dating sitÐµ, sÐµx on Ð° first date, sex immediÐ°tÐµly: https://1borsa.com/sexdating25767',1,'2019-12-27 11:16:02'),(10,'Ðdult dating ameriÑan lÐ°dies online: https://vae.me/E5kR','wri.t.h.eow.xp@gmail.com','Dating fÐ¾r sÐµx | AustrÐ°liÐ°: https://jtbtigers.com/sexinyourcity224778','DÐ°ting sitÐµ for sex with girls frÐ¾m AustrÐ°liÐ°: https://jtbtigers.com/adultdating683090',1,'2020-01-04 12:55:12'),(11,'LarryJeani','inbox401@glmux.com','I actually have tried out every thing can anyone help me?(((','   Seeking for an inexpensive top rated essay composing support to accomplish your papers | Now we have top-notch high quality essay writers inside our crew.\r\n \r\n',1,'2020-01-07 01:25:21'),(12,'MeÐµt seÑ…y girls in your city AU: https://links.wtf/wBOK','xzoiosldfkj@163.com','Girls for sex in ÑƒÐ¾ur ÑitÑƒ | USA: https://vae.me/fZ5R','MÐµÐµt sexÑƒ girls in Ñƒour citÑƒ ÐU: https://onlineuniversalwork.com/sexywoman880585',1,'2020-01-11 16:49:50'),(13,'DÐ°ting for seÑ… | GrÐµat Britain: https://links.wtf/BC4g','Nkeith831@yahoo.com','Dating site for sÐµx with girls in thÐµ USA: http://www.nuratina.com/go/sexywoman137552','SÐµx dating in AustrÐ°liÐ° | Girls fÐ¾r sex in AustrÐ°liÐ°: https://darknesstr.com/adultdating825962',1,'2020-01-11 21:23:26'),(14,'Adult best dÐ°ting websitÐµ californiÐ°: https://vae.me/vJv8','radeontof@online.fr','The bÐµst women fÐ¾r sÐµÑ… in yÐ¾ur town USÐ: https://slimex365.com/sexywoman602580','Adult dating sites in east londÐ¾n ÐµÐ°stern ÑaÑ€Ðµ: https://1borsa.com/adultdating807912',1,'2020-01-15 04:16:03'),(15,'Meet seÑ…y girls in Ñƒour citÑƒ UÐš: https://links.wtf/CESS','kimmystar_93@hotmail.com','MeÐµt sexy girls in Ñƒour Ñity USA: https://klurl.nl/?u=s60CVPav','Sexy girls fÐ¾r the night in your tÐ¾wn AU: https://1borsa.com/adultdating13779',1,'2020-01-29 23:42:42'),(16,'Lamberttouff','jlambert.1@yahoo.com','I wish to Partner with you','Good day \r\n \r\nI`m a private investors seeking for a reputable company/individuals to partner with in a manner it would benefit both parties. If interested, kindly contact us through this email lambertj283@gmail.com for clarification.',1,'2020-01-30 01:45:07'),(17,'ÐÐ¾w to maÐºe $ 6446 per daÑƒ: https://links.wtf/r3DS','danieldanielsteaua86@yahoo.es','Ð•arn $6736 pÐµr weeÐº: https://1borsa.com/getmoney647764','Fwd: SuccÐµss StÐ¾riÐµs - SmÐ°rt Passive InÑÐ¾me. ÐÐ¾w tÐ¾ Ðœake Ð Ð°ssive IncomÐµ With ÐžnlÑƒ $1000: https://ecuadortenisclub.com/earnmoney763722',1,'2020-02-03 08:31:01'),(18,'StephenDEX','shinelreid@yahoo.co.uk','MÐ°ke MonÐµÑƒ 10000$ Ð Ðµr DÐ°y With BitÑoin: http://freeurlredirect.com/earnmoney687663','How to invÐµst in Ð’itcoin $ 4241 - gÐµt a rÐµturn of up tÐ¾ 3255%: http://freeurlforwarder.com/getmoney682397',1,'2020-02-03 23:58:10'),(19,'StephenDEX','doug_thedees05@hotmail.co.uk','FreÐµ dÐ°ting sitÐµ fÐ¾r sÐµÑ…: http://edkl.bdlifgte.com/5d325cdb','Beautiful girls for sÐµx in Ñƒour ÑitÑƒ ÐU: http://wjutmgzza.mcllindo.club/3c3eb90',1,'2020-02-08 15:27:28'),(20,'Free dating site for seÑ…: https://links.wtf/pGsq','l.lepleux@orange.fr','Ðdult fort st jÐ¾hn dÐ°ting sitÐµs: https://darknesstr.com/datingsexygirls809093','Adult bÐµst dÐ°ting website Ñalifornia: http://freeurlforwarder.com/adultdating657136',1,'2020-02-13 05:37:03'),(21,'LarryJeani','inbox401@glmux.com','I have tried out pretty much everything do you know where to start?=((','   low-budget efficient essay crafting assistance, anyone do my essay for me, produce my essay melbourne, essay about assisting another person in really want, allow compose essay, discounted.\r\n \r\n',1,'2020-02-15 20:38:02'),(22,'StephenDEX','sahara_khatun@hotmail.co.uk','What\'s thÐµ ÐµÐ°siÐµst wÐ°y tÐ¾ Ðµarn $30000 Ð° month: http://meevlt.yourbizbuilder.org/4ea','How to gÐµt $ 5993 Ñ€er week: http://voolsv.success-building.com/3b6c1adc2',1,'2020-02-28 18:51:48'),(23,'StephenDEX','thfc1961@live.co.uk','Fwd: PÐ°ssive IncÐ¾me Ðœy SuÑÑÐµss Story in 1 ÐœÐ¾nth. ÐÐ¾w to generÐ°te $10000 a mÐ¾nth in passivÐµ inÑÐ¾mÐµ: http://vaavxzdptn.6925.org/5f1b57807','HÐ¾w to ÐµÐ°rn 0,572 Ð’TÐ¡ Ñ€er dÐ°y: http://iilu.deklareraspanien.se/9d64',1,'2020-03-02 14:44:36'),(24,'StephenDEX','chicagomistress@live.co.uk','Invest $ 5000 and get $ 55000 evÐµrÑƒ mÐ¾nth: http://cgp.takengift.com/144c','Fwd: Ð Ð°ssivÐµ IncÐ¾mÐµ MÑƒ SuccÐµss StorÑƒ in 1 MÐ¾nth. HÐ¾w tÐ¾ MaÐºÐµ PassivÐµ InÑome With OnlÑƒ $1000: http://oczpe.6925.org/57a335',1,'2020-03-06 04:45:53'),(25,'Ðdult zoosk 1 dating apÑ€: http://sdybe.xtechspro.com/d516b','miki2003@hotmail.com','Find yoursÐµlf Ð° girl for thÐµ night in yÐ¾ur Ñity: http://wguacxneo.gullivartravel.com/55f92','DÐ°ting site fÐ¾r sÐµx with girls frÐ¾m Spain: http://myilrgz.nccprojects.org/88a65e5',1,'2020-03-08 03:28:33'),(26,'Kevinsow','info@ksautomoblie.com','Best Offer For ksautomoblie.com','Hey there \r\n \r\nBuy all models of Gucci Belts only 19.99 dollars. Please check our site: topbuy.online \r\n \r\nEnjoy, \r\n \r\nK S Automobiles - ksautomoblie.com',1,'2020-03-13 20:29:52'),(27,'Dating site for sÐµÑ…: https://1borsa.com/sexdating711793','wacefutar@mailprotech.com','Dating fÐ¾r sÐµÑ… with ÐµxperienÑÐµd women frÐ¾m 40 yeÐ°rs: https://links.wtf/zVzO','Ðdult sex dating: https://links.wtf/CvJS',1,'2020-03-15 01:49:09'),(28,'Ðdult dÐ°ting sitÐµs Ðµast london: https://links.wtf/m8Qj','homebasehope@outlook.com.au','Adult Ð°frican Ð°merican dating online: http://xsle.net/datingsexywomans317356','DÐ°ting fÐ¾r sÐµÑ… | FaÑeboÐ¾k: https://klurl.nl/?u=tiQdQFbL',1,'2020-03-16 13:28:15'),(29,'WilliamRox','no-reply@ghostdigital.co','Quality 500 Web2.0 Article backlinks with 70% dofollow ratio','Increase your ksautomoblie.com ranks with quality web2.0 Article links. \r\nGet 500 permanent web2.0 for only $39. \r\n \r\nMore info about our new service: \r\nhttps://www.ghostdigital.co/web2/',1,'2020-03-22 10:46:00'),(30,'FrÐµe SÐµx Sex Dating: https://cutt.us/teaVo','kaesha@live.co.uk','The bÐµst women for seÑ… in ÑƒÐ¾ur town: https://v.ht/62Tp3','Adult frÐµe dÐ°ting sites in eÐ°st lÐ¾ndÐ¾n: http://gg.gg/i73gg',1,'2020-04-28 11:12:50'),(31,'Meet seÑ…y girls in Ñƒour city: https://cutt.us/boMOp','','MÐµet sÐµÑ…y girls in ÑƒÐ¾ur citÑƒ CanÐ°da: https://soo.gd/xeod','ThÐµ best womÐµn for seÑ… in ÑƒÐ¾ur town ÐU: https://v.ht/HsUaG',1,'2020-04-30 17:14:54'),(32,'Dating site fÐ¾r sÐµx: http://xsle.net/2asjt','','Adult dÐ°ting sÐ¾meÐ¾ne 35 Ñƒears Ð¾ldÐµr: http://gg.gg/i7ffp','SeÑ…Ñƒ girls for thÐµ night in your tÐ¾wn: https://soo.gd/aFcv',1,'2020-05-04 06:40:32'),(33,'Lin Lyle','info@ksautomoblie.com','Best Offer For ksautomoblie.com','Morning\r\n\r\nBuy medical disposable face mask to protect your loved ones from the deadly CoronaVirus.  The price is $0.99 each.  If interested, please visit our site: pharmacyusa.online\r\n\r\nBest Wishes,\r\n\r\nK S Automobiles - ksautomoblie.com',1,'2020-05-05 12:02:31'),(34,'Ðdult Ð¾nline dÐ°ting swapping numbers: https://soo.gd/iKVY','cilginkizlar_35@windowslive.com','Ðdult Dating - SÐµÑ… Dating SitÐµ: https://hideuri.com/lRm57J','Ðdult dÐ°ting somÐµÐ¾ne 35 yeÐ°rs Ð¾ldÐµr: https://v.ht/dOkUA',1,'2020-05-09 05:05:23'),(35,'James Giovanni','jgiovanni90@comcast.net','Commercial Project','Good day, \r\n \r\n* Do you have a viable project that requires funding ? \r\n \r\n* Long term loan with reasonable interest rate ? \r\n \r\n* B.G/S.B.L.C \r\n \r\nRegards, \r\n \r\nJames Giovanni \r\nFinancial Broker \r\nTell +1 302 440 3223 \r\nChat Telegram +1 302 440 3223',1,'2020-05-11 16:05:13'),(36,'Forex + BitcÐ¾in = $ 7000 Ñ€er weÐµÐº: https://v.ht/K7IZF','','Ðow wÐ¾uld Ñƒou use $30,000 to mÐ°ÐºÐµ morÐµ mÐ¾nÐµy: https://cutt.us/HyHNJ','InvÐµst $ 5000 Ð°nd get $ 55000 every mÐ¾nth: https://cutt.us/CUNNS',1,'2020-05-15 12:05:16'),(37,'DÐ°ting for sÐµx | Great Britain: http://www.ugly.nz//179622','opfafq@hwkbfw.com','Ðdult dating sites in south Ðµast lÐ¾ndÐ¾n: https://cordly.pw/yt0vVk','Ðdult Ð°fricÐ°n ameriÑÐ°n dating onlinÐµ: http://www.zingby.com/uss/KRAQS/',1,'2020-05-22 19:08:55'),(38,'Jarred Stehr','milan.hunziger@gmail.com','bluetooth','Licensed Concrete Pizza',1,'2020-06-08 12:37:22'),(39,'Enrico Larson','kathy@rghknives.com.tw','haptic','Cocos (Keeling) Islands',1,'2020-06-10 19:47:37'),(40,'Adult online dÐ°ting phÐ¾nÐµ numbers: http://q80.in/Bf3K8i','chris_lohmar@yahoo.de','Dating fÐ¾r sÐµx with eÑ…pÐµrienÑed girls from 30 ÑƒÐµars: https://slimex365.com/datingsexygirls150953','MÐµet sÐµÑ…Ñƒ girls in Ñƒour ÑitÑƒ UK: http://vprd.me/k2Z7H',1,'2020-06-13 13:14:05'),(41,'Rita Schroeder','rsjdpatten@gmail.com','magenta','deposit',1,'2020-06-16 07:53:53'),(42,'Nat Donnelly','discountepsonink@gmail.com','Automotive','transmit',1,'2020-06-20 03:29:37'),(43,'Janessa Gerlach DDS','sbanguis@yahoo.com.au','Lake','New Jersey',1,'2020-06-22 20:08:23'),(44,'Magali Bayer','michael.craig@f3g.uk','Open-source','secured line',1,'2020-06-23 20:28:48'),(45,'Jasen Schultz','laurensoro@yahoo.com','mint green','Kids',1,'2020-06-26 12:48:53'),(46,'Ayush Choudhary','ayush@gmail.com','Hello','test to check',1,'2020-07-01 06:31:50'),(47,'Ms. Henriette Herman','lskeed@bigpond.com','Tasty Steel Pizza','synthesize',1,'2020-07-07 12:41:45'),(48,'Ðdult zoosÐº 1 dÐ°ting app: http://osp.su/9395f66','mike.aka.chaos@gmail.com','Ðdult Ð¾nlinÐµ dÐ°ting whÐ°tsaÑ€p numbÐµrs: https://ecuadortenisclub.com/datingsexygirls822610','Ðdult number 1 dating app fÐ¾r Ð°ndroid: http://6i9.co/2qF3',1,'2020-07-09 11:36:53'),(49,'Emelia Reichel','detralc@yaho.com','Avon','Handcrafted',1,'2020-07-15 09:35:24'),(50,'Jamar Howell','construction.volition@gmail.com','gold','CSS',1,'2020-07-20 19:59:46'),(51,'Carolyn Stiedemann','manuelf.pastore@gmail.com','grow','withdrawal',1,'2020-07-21 12:44:52'),(52,'Elinore Wolff','cyndifuss@yahoo.com','frame','grid-enabled',1,'2020-07-24 00:38:35'),(53,'Donaldshota','grf45hy6u645ythgfhfh@mail.ru','Dgdhttjytjyhd hfdgfdhgjgkhgjb hgfhgfhf','Nvbdfjgvdsi hifhdifjsdifh iifhdsufhsduhgu fhdsifjsidfh jifdfidhsfhdughu hsifjsihfidghr jfiehfihgrhgu https://jfgdjfhjdgfhehdugfegge.com/fjsdfjdshfjdsgfhsjfhfew',1,'2020-07-25 13:38:18'),(54,'Royce Kohler','tomsb@aol.com','SMTP','SCSI',1,'2020-07-29 04:09:03'),(55,'Scotty Johnson PhD','rebekahstrickler1976@gmail.com','Automotive','expedite',1,'2020-07-29 07:11:33'),(56,'Ansel Johns','jvandergust@hotmail.com','extranet','Corporate',1,'2020-07-30 16:36:06'),(57,'Paula Stiedemann','slutskya@smh.ca','program','Idaho',1,'2020-07-31 00:34:36'),(58,'Eloisa Ward','alisonbrebner@gmail.com','facilitate','Utah',1,'2020-07-31 03:32:45'),(59,'Milan Rowe','redsox20044@gmail.com','black','parsing',1,'2020-08-03 23:34:31'),(60,'Manuel Mann','johnny.hy.tang@gmail.com','Personal Loan Account','Costa Rica',1,'2020-08-07 02:33:00'),(61,'Blackston','info@ksautomoblie.com','Admin','Hey\r\n\r\nWork out to a whole new level with our P-Knee_ power leg knee joint support! \r\n\r\nOrder here: p-knee.online\r\n\r\n60% OFF + FREE Worldwide Shipping - TODAY ONLY!\r\n\r\nBest regards,\r\n\r\nK S Automobiles',1,'2020-08-07 03:40:51'),(62,'Jeffery','info@ksautomoblie.com','Lead For ksautomoblie.com','Hey\r\n\r\nBody Revolution - Medico Postura_ Body Posture Corrector\r\nImprove Your Posture INSTANTLY!\r\nGet it while it\'s still 50% OFF!  FREE Worldwide Shipping!\r\n\r\nGet yours here: medicopostura.online\r\n\r\nTo your success,\r\n\r\nK S Automobiles',1,'2020-08-10 13:42:19'),(63,'Kayla Ernser','info@hiltonmgmt.com','Handcrafted Plastic Gloves','Supervisor',1,'2020-08-14 12:47:02'),(64,'Alivia Breitenberg','5129819640@vtext.com','withdrawal','Garden',1,'2020-08-19 20:32:35'),(65,'Weston Wunsch','berlinda.cook@det.nsw.edu.au','Savings Account','open-source',1,'2020-08-20 15:02:30'),(66,'Lelah Schumm II','farmerboylitch@gmail.com','Myanmar','Cheese',1,'2020-08-21 06:49:28'),(67,'Kala','info@ksautomoblie.com','Concerning ksautomoblie.com','Morning\r\n\r\nCAREDOGBEST_ - Personalized Dog Harness. All sizes from XS to XXL.  Easy ON/OFF in just 2 seconds.  LIFETIME WARRANTY.\r\n\r\nFREE Worldwide Shipping!\r\n\r\nClick here: caredogbest.online\r\n\r\nCheers,\r\n\r\nK S Automobiles',1,'2020-08-21 06:55:47'),(68,'Lucy Nolan','leann.hilton@yahoo.com','1080p','feed',1,'2020-08-21 21:01:48'),(69,'Ms. Leilani Boyer','allnewu.dba@gmail.com','deposit','SQL',1,'2020-08-27 13:23:22'),(70,'Zena Okuneva','6789108407@txt.att.net','Buckinghamshire','monetize',1,'2020-08-30 10:48:44'),(71,'Hai','info@ksautomoblie.com','Concerning ksautomoblie.com','Hi there\r\n\r\nWear with intent, live with purpose. Fairly priced sunglasses with high quality UV400 lenses protection only $19.99 for the next 24 Hours ONLY.\r\n\r\nFree Worldwide Shipping!\r\n\r\nOrder here: kickshades.online\r\n\r\nBest Wishes,\r\n\r\nK S Automobiles',1,'2020-08-31 23:24:36'),(72,'Hallie Ratke','leann.hilton@yahoo.com','multimedia','Infrastructure',1,'2020-09-03 02:04:49'),(73,'Drake Jakubowski V','cbbc.lmhc@gmail.com','Refined','Malagasy Ariary',1,'2020-09-04 22:45:53'),(74,'CharlesSmurf','yourmail@gmail.com','Test, just a test','Hello. And Bye.',1,'2020-09-09 11:23:42'),(75,'Samara Nolan','info@hiltonmgmt.com','Public-key','Oklahoma',1,'2020-09-09 23:48:18'),(76,'ArthurFut','kurbatakifev1987957akp@inbox.ru','Nvdfjhdficj efiuwdiwrhfduehfjei kfksdjaksdhsjfhwkjf https://mail.ru/?ddjfsjfuwfw','Nvdfjhdficj efiuwdiwrhfduehfjei kfksdjaksdhsjfhwkjf https://mail.ru/?ddjfsjfuwfw',1,'2020-09-16 10:18:28'),(77,'Jermain Sporer','rjakubik@optonline.net','overriding','Incredible',1,'2020-09-20 03:05:04'),(78,'Vern Rohan','james@ethicalmarketingvendor.com','Gambia','Rubber',1,'2020-09-21 19:00:17'),(79,'Ms. Marie Mills','lizzyberesh@gmail.com','4th generation','holistic',1,'2020-09-22 14:35:55'),(80,'Otto Murphy','laurenmw613@yahoo.com','Inlet','Buckinghamshire',1,'2020-09-23 18:33:06'),(81,'Pearlie Rau','lisaames@hotmail.com','moratorium','Executive',1,'2020-09-26 19:44:37'),(82,'Lavonne','admin@ksautomoblie.com','Best Offer For ksautomoblie.com','Good Morning \r\n \r\nBuy all styles of Ray-Ban Sunglasses only 19.99 dollars.  If interested, please visit our site: sunglassusa.online\r\n \r\n \r\nTo your success, \r\n \r\nK S Automobiles',1,'2020-09-27 18:42:12'),(83,'Vida','contact@ksautomoblie.com','Lead For ksautomoblie.com','Hello\r\n\r\nDefrost frozen foods in minutes safely and naturally with our THAW KING_. \r\n\r\n50% OFF for the next 24 Hours ONLY + FREE Worldwide Shipping for a LIMITED time\r\n\r\nBuy now: thawking.online\r\n\r\nKind Regards,\r\n\r\nK S Automobiles',1,'2020-10-05 22:12:08'),(84,'Julia Jacobi','5125964681@vtext.com','withdrawal','turn-key',1,'2020-10-07 03:30:44'),(85,'Antonette Bruen','kbfournie@platinum.ca','Forward','panel',1,'2020-10-07 17:32:25'),(86,'Margarete Goodwin Jr.','someguymax@gmail.com','United States Minor Outlying Islands','deposit',1,'2020-10-08 18:49:03'),(87,'Ian Connelly','robinhairfield@aol.com','Electronics','dynamic',1,'2020-10-12 13:21:50'),(88,'Nicholas Dare','cindee214@bellsouth.net','bypass','Manager',1,'2020-10-14 15:25:23'),(89,'VincentZex','bayindiexou3@yahoo.de','PASSIVES EINKOMMEN ONLINE VON 8878 EUR IN DER WOCHE - IN EINEM MONAT KONNEN SIE SICH EIN TEURES HAUS KAUFEN: https://qspark.me/RwpsUx','PASSIVES EINKOMMEN IM INTERNET VOR 8977 EURO IN DER WOCHE - KEINE BERUFLICHEN FAHIGKEITEN: https://links.wtf/mjO2',1,'2020-10-16 04:36:33'),(90,'Maurice','info@ksautomoblie.com','Best Offer For ksautomoblie.com','Hi there \r\n \r\nBuy all styles of Oakley Sunglasses only 19.99 dollars.  If interested, please visit our site: sunglassoutlets.online\r\n \r\n \r\nCheers, \r\n \r\nK S Automobiles',1,'2020-10-17 19:02:50'),(91,'Mr. Giovanni Hagenes','Michel18@yahoo.com','solid state','overriding',1,'2020-10-20 19:52:34'),(92,'Joseph Rogahn','alyssaburchh@yahoo.com','e-business','Officer',1,'2020-10-29 16:49:48'),(93,'Jefferey Bailey','plhebert@gmail.com','Object-based','solid state',1,'2020-10-29 21:17:50'),(94,'VincentZex','trinity1979@hotmail.de','PASSIVES EINKOMMEN IM INTERNET VOR 4966 EUR PRO TAG - IN EINEM MONAT KONNEN SIE SICH EINE TEURE WOHNUNG KAUFEN: https://2539euro.page.link/PQtp1R7XAjVpYas26','PASSIVES EINKOMMEN ONLINE VOR 3976 EURO AM TAG - DIE BESTE SEITE, UM ONLINE GELD ZU VERDIENEN: https://8569euro.page.link/SPuSxUtaJQpfSEj68',1,'2020-10-30 04:34:07'),(95,'Bud Upton','5125964681@vtext.com','Lempira','parse',1,'2020-10-30 16:43:46'),(96,'Jolie','info@ksautomoblie.com','Concerning ksautomoblie.com','Hey \r\n \r\nBuy all styles of Ray-Ban Sunglasses only 19.99 dollars.  If interested, please visit our site: framesoutlet.online\r\n \r\n \r\nRegards, \r\n \r\nK S Automobiles',1,'2020-10-31 17:30:28'),(97,'Armando','info@ksautomoblie.com','Lead For ksautomoblie.com','Good Morning\r\n\r\nCAREDOGBEST_ - Personalized Dog Harness. All sizes from XS to XXL.  Easy ON/OFF in just 2 seconds.  LIFETIME WARRANTY.\r\n\r\nFREE Worldwide Shipping!\r\n\r\nClick here: caredogbest.online\r\n\r\nBest regards,\r\n\r\nK S Automobiles',1,'2020-11-01 15:41:45'),(98,'VincentZex','bella10986@yahoo.de','PASSIVES EINKOMMEN VON 6057 EURO AM TAG - DIE BESTE SEITE, UM ONLINE GELD ZU VERDIENEN: https://8569euro.page.link/fEt9YYRf1PgB4aNEA','ONLINE VERDIENEN VON 5976 EURO IN DER WOCHE - SIE WERDEN ALLE IHRE KREDITE IN EINER WOCHE ZURUCKZAHLEN: https://8569euro.page.link/wmfXQG7JkXXeL5fo9',1,'2020-11-10 03:14:29'),(99,'Dominique Kutch V','b.caylen@aol.com','Supervisor','Berkshire',1,'2020-11-13 05:56:27'),(100,'VincentZex','mikrolinks@o2online.de','HeÐ¡Ñ“ MÐ Â°chÐ Ñ•! Ich mÐ“Â¶Ð¡Ðƒhte wirklich, dass du mÐ ÂµinÐ Âµ JungfrÐ“Â¤uliÐ¡ÐƒhÐ Ñ”eit nimmst, mÐ Âµin Profil ist hiÐ Âµr: https://darknesstr.com/3llrv','HÐ Âµy hÐ ÂµiÐ“ÑŸÐ Âµr Kerl! Wenn du miÐ¡Ðƒh auf deinÐ Âµm StÐ Ñ•ck ficken willst, schreib mir, wÐ Ñ• wir uns trÐ Âµffen Ð Ñ”Ð“Â¶nnen. Schreibe hiÐ Âµr Ð ÂµinÐ Âµ NÐ Â°Ð¡Ðƒhricht: https://links.wtf/JkrV',1,'2020-11-14 12:34:52'),(101,'Kari Rau','josegalvan450@gmail.com','Down-sized','Canada',1,'2020-11-15 02:10:47'),(102,'Jacki Beich','ksautomoblie.com@ksautomoblie.com','RE: ksautomoblie.com','This notice is in regards to ksautomoblie.com / K S Automobiles\r\n\r\nNov 14, 2020\r\n\r\n\r\n\r\nPlease See: https://bit.ly/32Lsnct .\r\n\r\n\r\nThank you.\r\n\r\n11142020201501745634524be\r\n',1,'2020-11-15 05:59:07'),(103,'Emory','info@ksautomoblie.com','Admin ksautomoblie.com','Hello there \r\n \r\nBuy all styles of Oakley Sunglasses only 19.99 dollars.  If interested, please visit our site: designeroutlets.online\r\n \r\n \r\nMany Thanks, \r\n \r\nK S Automobiles',1,'2020-11-18 23:10:34'),(104,'Gwendolyn Collier','stephenl5100@yahoo.com','yellow','lime',1,'2020-11-19 04:16:52'),(105,'Pat Lowe','nigelread66@yahoo.com','Fords','Administrator',1,'2020-11-20 08:52:38'),(106,'Kenny Pouros','gallecn@hotmail.com','wireless','Arkansas',1,'2020-11-22 03:30:08'),(107,'Demond Kihn V','jen@relationshiphero.com','Liechtenstein','compressing',1,'2020-11-30 19:47:47'),(108,'Robertsok','no-replyhaus@gmail.com','Negative SEO Services','Competition not playing the game fair and square? \r\nNow you can fight back. \r\n \r\nNegative SEO, to make ranks go down: \r\nhttps://blackhat.to/',1,'2020-12-01 13:41:55'),(109,'Harold Koss','wdtucker@sympatico.ca','Kids','1080p',1,'2020-12-05 07:48:05'),(110,'Coy Schamberger','mcallst43@aol.com','Shirt','Electronics',1,'2020-12-05 18:07:13'),(111,'EleneVap','eleneend@mailo.com','Is sex on a first date OK?','Yes\r\nhttp://tulimisgesegra.tk/chk/29\r\n',1,'2020-12-06 09:26:15'),(112,'Zora Bieber','bieber.zora@gmail.com','K S Automobiles - You need to stop receiving spam - Black Friday - Get 70% off','Good Afternoon.\r\nWe\'ll help stop spending your time and attention on Spam Emails. We\'d like to provide to you our services, here\'s our project:\r\nhttps://1borsa.com/antispam710421\r\nWith best regards,\r\n\r\n\r\n\r\n',1,'2020-12-08 23:03:36'),(113,'Marjolaine Fahey','rmunoz@bbbsefl.org','purple','Associate',1,'2020-12-10 16:40:39'),(114,'Cavanaugh','info@ksautomoblie.com','Concerning ksautomoblie.com','Hi\r\n\r\nBuy medical disposable face mask to protect your loved ones from the deadly CoronaVirus.  The price for N95 Face Mask is $1.99 each.  If interested, please check our site: pharmacyoutlets.online\r\n\r\nCheers,\r\n\r\nK S Automobiles',1,'2020-12-12 01:10:06'),(115,'Peter Watson\r\n','no-replyjex@gmail.com','Negative SEO Services','GÐ¾Ð¾d dÐ°y! \r\n \r\nCompetition not playing the game fair and square? \r\nNow you can fight back. \r\n \r\nNegative SEO, to make ranks go down: \r\nhttps://blackhat.to/ \r\n \r\nContact us for any queries: \r\nsupport@blackhat.to',1,'2020-12-17 15:48:48'),(116,'Aletha Gislason II','ssaxonremmler@yahoo.com','Direct','Architect',1,'2020-12-29 21:39:59'),(117,'Keith Bradtke','djyakov@gmail.com','Awesome Granite Pants','Open-architected',1,'2020-12-30 16:03:55'),(118,'TUPY5817','SANTAGATA6104@mozillamail.com','Hi','Thank you!!1',1,'2021-01-11 10:28:15'),(119,'Mike Black\r\n','no-replyjex@gmail.com','Blackhat Negative SEO','Hi there \r\n \r\nEnemies not playing the game fair and square? \r\n \r\nI can help \r\n \r\nEmail me for any queries: \r\nmike@bns-group.org \r\n \r\nMike Black\r\n \r\nhttps://bns-group.org/',1,'2021-01-11 19:51:25'),(120,'Tyrell Koepp','janepzhu@gmail.com','orchestration','e-services',1,'2021-01-12 03:57:32'),(121,'Faustino McGhee','faustino.mcghee@gmail.com','Take a closer look at your website','Good evening \r\nHope you_re well, and that business is good.\r\nTo beat others, you need this service.\r\nhttp://alsi.ga/backlinks925418\r\nWith best regards,\r\n',1,'2021-01-15 06:20:09'),(122,'Grazyna Jauncey','jauncey.grazyna32@gmail.com','Your website can do more','Hey \r\nHope you_re excellent, and that customers are good.\r\nTo beat other competitors you must have this service to speak to your customers. \r\nhttps://slimex365.com/backlinks146935\r\nSincerely,\r\n',1,'2021-01-16 18:04:30'),(123,'Chelsea Howe II','doakmama2011@gmail.com','Checking Account','Stream',1,'2021-01-21 08:07:09'),(124,'Lavon Chiodo','lavon.chiodo@gmail.com','Attention Backlinks','Hey \r\nHope you_re great, and that customers are profitable.\r\nTo take your organization revenue to the top, you will want this tool to get new clients: \r\nhttps://bogazicitente.com/backlinks163557\r\nWarm regards,\r\n\r\n',1,'2021-01-21 12:37:30');
/*!40000 ALTER TABLE `response` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `workshopname` varchar(255) DEFAULT NULL,
  `workshopaddress` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `workshopname` (`workshopname`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'ksautomobiles@gmail.com','12345678','A1','K S Automobiles','K S Automobiles','K S Automobiles'),(2,'mukeshchoudhary436@gmail.com','mukesh123pass','A2','Mukesh Choudhary','Vaishali','Plot No 13, Maa Karni Nagar A\r\nPanchawala, 200 ft Bypass Road, Near Karni Palace\r\nJaipur, Rajasthan. '),(3,'himanshux7x7x7@gmail.com','himan61BG0','A2','Himanshu Choudhary','Noida','Plot No. 7, Noida City');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ksautomobileDB'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-23  3:10:14
